BIG Delivery Cash Manager — مشروع Android أصلي

هذا مشروع Android Studio قابل للبناء، وليس ملف APK جاهزاً بعد.
لبناء APK:
1) افتح المشروع في Android Studio على حاسوب.
2) ثبّت Android SDK Platform 35 وJDK 17.
3) اختر Build > Build APK(s).
4) ستجد الملف في app/build/outputs/apk/debug/app-debug.apk

يوجد GitHub Actions workflow داخل .github/workflows/build-apk.yml لبناء APK تلقائياً بعد رفع المشروع إلى مستودع GitHub وتشغيل Actions.

الميزات: إدارة الموزعين والشركات، تسجيل الكاش والدفعات، الرصيد اليومي، أرشفة اليوم والرجوع للتاريخ، حفظ محلي عبر SharedPreferences.
ملاحظة: هذه نسخة أولية تحتاج اختباراً على جهاز حقيقي قبل الاعتماد عليها في حسابات مالية فعلية. البيانات محفوظة على الجهاز فقط. لا يوجد مزامنة سحابية أو قفل PIN في هذه النسخة.

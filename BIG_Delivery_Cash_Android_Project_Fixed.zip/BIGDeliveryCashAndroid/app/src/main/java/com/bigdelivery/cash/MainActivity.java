package com.bigdelivery.cash;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    final int NAVY=Color.rgb(11,27,54), BLUE=Color.rgb(18,103,241), ORANGE=Color.rgb(255,120,31),
        BG=Color.rgb(243,246,251), INK=Color.rgb(20,35,61), MUTED=Color.rgb(113,128,154),
        GREEN=Color.rgb(19,155,105), RED=Color.rgb(229,72,77), LINE=Color.rgb(231,237,245);
    JSONObject data, current;
    JSONArray couriers, companies, days, receipts, payments;
    LinearLayout root, content, header, nav;
    String page="dashboard";
    SharedPreferences prefs;
    public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(NAVY);getWindow().setNavigationBarColor(NAVY);prefs=getSharedPreferences("bigcash",0);load();buildShell();render();}
    JSONObject obj(){return new JSONObject();}
    JSONArray arr(){return new JSONArray();}
    void load(){
        try {
            String raw=prefs.getString("state",null);
            if(raw==null){data=obj();couriers=arr();companies=arr();days=arr();current=obj();receipts=arr();payments=arr();current.put("date",today());current.put("receipts",receipts);current.put("payments",payments);current.put("closed",false);data.put("couriers",couriers);data.put("companies",companies);data.put("days",days);data.put("current",current);save();}
            else {data=new JSONObject(raw);couriers=data.getJSONArray("couriers");companies=data.getJSONArray("companies");days=data.getJSONArray("days");current=data.getJSONObject("current");receipts=current.getJSONArray("receipts");payments=current.getJSONArray("payments");}
        }catch(Exception e){data=obj();couriers=arr();companies=arr();days=arr();current=obj();receipts=arr();payments=arr();try{current.put("date",today());current.put("receipts",receipts);current.put("payments",payments);}catch(Exception x){}}
    }
    void save(){try{current.put("receipts",receipts);current.put("payments",payments);data.put("couriers",couriers);data.put("companies",companies);data.put("days",days);data.put("current",current);prefs.edit().putString("state",data.toString()).apply();}catch(Exception e){}}
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.FRANCE).format(new Date());}
    String fmt(double n){return NumberFormat.getNumberInstance(Locale.FRANCE).format(n)+" DH";}
    double sum(JSONArray a){double n=0;for(int i=0;i<a.length();i++)n+=a.optJSONObject(i).optDouble("amount",0);return n;}
    double sumFor(JSONArray a,String id){double n=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(id.equals(o.optString("entityId")))n+=o.optDouble("amount",0);}return n;}
    double cash(){return sum(receipts);} double paid(){return sum(payments);} double balance(){return cash()-paid();}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    TextView button(String s,int color,int fg,Runnable action){TextView t=text(s,13,fg,true);t.setGravity(Gravity.CENTER);pad(t,12,13,12,13);t.setBackground(bg(color,14));t.setOnClickListener(v->action.run());return t;}
    void buildShell(){
        root=column();root.setBackgroundColor(BG);setContentView(root);
        header=column();header.setBackground(bg(NAVY,0));pad(header,18,17,18,18);
        LinearLayout brand=row();TextView logo=text("B",20,Color.WHITE,true);logo.setGravity(Gravity.CENTER);logo.setBackground(bg(ORANGE,14));brand.addView(logo,lp(44,44));
        LinearLayout brandtxt=column();pad(brandtxt,10,0,0,0);brandtxt.addView(text("BIG DELIVERY",17,Color.WHITE,true));brandtxt.addView(text("CASH MANAGER",10,Color.rgb(185,201,225),true));brand.addView(brandtxt,new LinearLayout.LayoutParams(0,-2,1));
        brand.addView(button("+ Nouveau jour",Color.rgb(233,240,255),BLUE,()->newDayConfirm()));header.addView(brand);TextView date=text(today(),12,Color.rgb(200,215,235),false);pad(date,0,13,0,0);header.addView(date);root.addView(header,lp(-1,-2));
        ScrollView sc=new ScrollView(this);content=column();pad(content,16,14,16,20);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setBackgroundColor(Color.WHITE);String[][] items={{"⌂","Accueil","dashboard"},{"♙","Livreurs","couriers"},{"▤","Sociétés","companies"},{"◷","Historique","history"},{"⚙","Réglages","settings"}};
        for(String[] it:items){
            final String targetPage=it[2];
            LinearLayout item=column();
            item.setGravity(Gravity.CENTER);
            item.setClickable(true);
            item.setFocusable(true);
            item.setBackgroundResource(android.R.drawable.list_selector_background);
            pad(item,3,8,3,8);
            TextView icon=text(it[0],20,BLUE,true);
            icon.setGravity(Gravity.CENTER);
            icon.setClickable(false);
            TextView label=text(it[1],10,MUTED,true);
            label.setGravity(Gravity.CENTER);
            label.setClickable(false);
            item.addView(icon);
            item.addView(label);
            View.OnClickListener navigationClick=v->{page=targetPage;render();};
            item.setOnClickListener(navigationClick);
            icon.setOnClickListener(navigationClick);
            label.setOnClickListener(navigationClick);
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(64),1));
        }
        root.addView(nav,lp(-1,-2));
    }
    void heading(String title,String sub){content.addView(text(title,22,INK,true));TextView s=text(sub,12,MUTED,false);pad(s,0,4,0,13);content.addView(s);}
    LinearLayout card(){LinearLayout c=column();c.setBackground(bg(Color.WHITE,18));pad(c,15,15,15,15);LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(11);content.addView(c,p);return c;}
    void metric(LinearLayout c,String label,double value,int accent,String symbol){LinearLayout r=row();TextView icon=text(symbol,22,accent,true);icon.setGravity(Gravity.CENTER);icon.setBackground(bg(accent==GREEN?0xffe4f8ef:accent==RED?0xfffff0ef:0xfffff0e5,14));r.addView(icon,lp(44,44));LinearLayout box=column();pad(box,12,0,0,0);box.addView(text(label,11,MUTED,true));box.addView(text(fmt(value),22,accent,true));r.addView(box);c.addView(r);}
    void render(){content.removeAllViews();if(page.equals("dashboard"))dashboard();else if(page.equals("couriers"))entities(true);else if(page.equals("companies"))entities(false);else if(page.equals("history"))history();else settings();for(int i=0;i<nav.getChildCount();i++){LinearLayout item=(LinearLayout)nav.getChildAt(i);String[] p={"dashboard","couriers","companies","history","settings"};TextView icon=(TextView)item.getChildAt(0),label=(TextView)item.getChildAt(1);icon.setTextColor(page.equals(p[i])?BLUE:MUTED);label.setTextColor(page.equals(p[i])?BLUE:MUTED);}}
    void dashboard(){
        heading("Vue d’ensemble","Suivi du cash — journée en cours");
        LinearLayout c=card();metric(c,"TOTAL CASH REÇU",cash(),GREEN,"↓");
        c=card();metric(c,"TOTAL PAYÉ AUX SOCIÉTÉS",paid(),RED,"↗");
        c=card();metric(c,"RESTE EN CAISSE",balance(),ORANGE,"▣");
        LinearLayout r=row();TextView a=button("+ Cash reçu",BLUE,Color.WHITE,()->transaction(true,null));TextView b=button("+ Paiement",ORANGE,Color.WHITE,()->transaction(false,null));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);p.rightMargin=dp(7);r.addView(a,p);r.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));LinearLayout.LayoutParams rp=lp(-1,-2);rp.bottomMargin=dp(13);content.addView(r,rp);
        c=card();c.addView(text("Dernières opérations",15,INK,true));JSONArray tx=allTx(current);if(tx.length()==0)c.addView(empty("Aucune opération pour le moment."));else for(int i=Math.max(0,tx.length()-5);i<tx.length();i++){JSONObject o=tx.optJSONObject(i);addTxRow(c,o);}
    }
    TextView empty(String s){TextView t=text(s,13,MUTED,false);t.setGravity(Gravity.CENTER);pad(t,5,20,5,20);return t;}
    JSONArray allTx(JSONObject day){JSONArray out=arr();JSONArray a=day.optJSONArray("receipts"),b=day.optJSONArray("payments");if(a!=null)for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);try{o.put("type","receipt");out.put(o);}catch(Exception e){}}if(b!=null)for(int i=0;i<b.length();i++){JSONObject o=b.optJSONObject(i);try{o.put("type","payment");out.put(o);}catch(Exception e){}}return out;}
    void addTxRow(LinearLayout c,JSONObject o){LinearLayout r=row();TextView n=text(o.optString("name"),13,INK,true);r.addView(n,new LinearLayout.LayoutParams(0,-2,1));boolean rec=o.optString("type").equals("receipt");r.addView(text((rec?"+ ":"− ")+fmt(o.optDouble("amount")),13,rec?GREEN:RED,true));pad(r,0,12,0,12);c.addView(r);View line=new View(this);line.setBackgroundColor(LINE);c.addView(line,lp(-1,1));}
    JSONArray list(boolean courier){return courier?couriers:companies;}
    void entities(boolean courier){heading(courier?"Livreurs":"Sociétés",courier?"Choisissez un livreur et saisissez le total remis.":"Consultez les paiements effectués aux sociétés.");content.addView(button(courier?"+ Ajouter un livreur":"+ Ajouter une société",BLUE,Color.WHITE,()->addName(courier)));content.addView(new View(this),lp(1,10));JSONArray arr=list(courier);if(arr.length()==0){content.addView(card());content.addView(empty(courier?"Aucun livreur. Ajoutez un nom pour commencer.":"Aucune société. Ajoutez un nom pour commencer."));return;}for(int i=0;i<arr.length();i++){JSONObject e=arr.optJSONObject(i);String id=e.optString("id"),name=e.optString("name");LinearLayout c=card();c.addView(text(name,15,INK,true));c.addView(text((courier?"Total reçu aujourd’hui : ":"Payé aujourd’hui : ")+fmt(sumFor(courier?receipts:payments,id)),12,courier?GREEN:RED,false));TextView b=button(courier?"+ Montant reçu":"+ Paiement",courier?0xffeaf1ff:0xfffff0e5,courier?BLUE:ORANGE,()->transaction(courier,id));LinearLayout.LayoutParams p=lp(-1,42);p.topMargin=dp(10);c.addView(b,p);}}
    void addName(boolean courier){EditText input=new EditText(this);input.setSingleLine(true);input.setHint(courier?"Nom du livreur":"Nom de la société");LinearLayout box=column();pad(box,20,8,20,8);box.addView(input);new AlertDialog.Builder(this).setTitle(courier?"Ajouter un livreur":"Ajouter une société").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty())return;JSONArray a=list(courier);for(int i=0;i<a.length();i++)if(a.optJSONObject(i).optString("name").equalsIgnoreCase(name)){msg("Ce nom existe déjà");return;}JSONObject e=obj();try{e.put("id",UUID.randomUUID().toString());e.put("name",name);a.put(e);}catch(Exception ex){}save();render();}).show();}
    void transaction(boolean receipt,String selected){JSONArray arr=list(receipt);if(arr.length()==0){msg(receipt?"Ajoutez d’abord un livreur":"Ajoutez d’abord une société");page=receipt?"couriers":"companies";render();return;}LinearLayout form=column();pad(form,20,4,20,0);Spinner spinner=new Spinner(this);ArrayList<String> names=new ArrayList<>();int idx=0;for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);names.add(o.optString("name"));if(o.optString("id").equals(selected))idx=i;}ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);spinner.setAdapter(ad);spinner.setSelection(idx);EditText amount=new EditText(this);amount.setHint("Montant en DH");amount.setInputType(8194);EditText note=new EditText(this);note.setHint("Note (facultative)");form.addView(text(receipt?"Livreur":"Société",12,MUTED,true));form.addView(spinner);form.addView(text("Montant (DH)",12,MUTED,true));form.addView(amount);form.addView(text("Note",12,MUTED,true));form.addView(note);
        new AlertDialog.Builder(this).setTitle(receipt?"Cash reçu":"Paiement société").setView(form).setNegativeButton("Annuler",null).setPositiveButton("Confirmer",(d,w)->{try{double n=Double.parseDouble(amount.getText().toString().replace(',','.'));if(n<=0)throw new Exception();JSONObject ent=arr.optJSONObject(spinner.getSelectedItemPosition()),t=obj();t.put("id",UUID.randomUUID().toString());t.put("entityId",ent.optString("id"));t.put("name",ent.optString("name"));t.put("amount",n);t.put("note",note.getText().toString().trim());t.put("date",System.currentTimeMillis());(receipt?receipts:payments).put(t);save();render();msg("Opération enregistrée");}catch(Exception ex){msg("Montant invalide");}}).show();}
    void newDayConfirm(){new AlertDialog.Builder(this).setTitle("Commencer un nouveau jour ?").setMessage("La journée du "+current.optString("date")+" sera archivée. Le nouveau solde commencera à 0 DH. Les noms et l’historique seront conservés.\\n\\nCash reçu : "+fmt(cash())+"\\nPayé : "+fmt(paid())+"\\nReste : "+fmt(balance())).setNegativeButton("Annuler",null).setPositiveButton("Archiver & continuer",(d,w)->{try{current.put("closed",true);days.put(current);current=obj();receipts=arr();payments=arr();current.put("date",today());current.put("receipts",receipts);current.put("payments",payments);current.put("closed",false);save();page="dashboard";render();msg("Nouvelle journée : solde à 0 DH");}catch(Exception e){}}).show();}
    void history(){heading("Historique","Les journées clôturées restent consultables.");for(int i=-1;i<days.length();i++){JSONObject d=i<0?current:days.optJSONObject(days.length()-1-i);JSONArray r=d.optJSONArray("receipts"),p=d.optJSONArray("payments");double c=sum(r==null?arr():r),v=sum(p==null?arr():p);LinearLayout card=card();card.addView(text((d.optBoolean("closed")?"Journée du ":"Journée en cours · ")+d.optString("date"),15,INK,true));card.addView(text("Total cash : "+fmt(c),13,GREEN,true));card.addView(text("Total payé : "+fmt(v),13,RED,true));card.addView(text("Reste : "+fmt(c-v),13,ORANGE,true));TextView view=button("Voir les opérations",0xffeaf1ff,BLUE,()->viewDay(d));LinearLayout.LayoutParams lp=lp(-1,42);lp.topMargin=dp(9);card.addView(view,lp);}}
    void viewDay(JSONObject d){StringBuilder s=new StringBuilder();JSONArray tx=allTx(d);for(int i=0;i<tx.length();i++){JSONObject o=tx.optJSONObject(i);s.append(o.optString("name")).append(" — ").append(fmt(o.optDouble("amount"))).append(o.optString("type").equals("receipt")?" (Cash reçu)":" (Paiement)").append("\\n");}new AlertDialog.Builder(this).setTitle("Journée du "+d.optString("date")).setMessage(s.length()==0?"Aucune opération":s.toString()).setPositiveButton("Fermer",null).show();}
    void settings(){heading("Réglages","Sauvegarde locale des données.");LinearLayout c=card();c.addView(text("Les données sont enregistrées sur ce téléphone. Elles ne sont pas synchronisées avec d’autres appareils.",13,MUTED,false));c.addView(button("Exporter une sauvegarde",BLUE,Color.WHITE,()->exportBackup()));c.addView(text("Pour éviter de perdre vos données, exportez régulièrement une sauvegarde.",12,MUTED,false));}
    void exportBackup(){try{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"big-delivery-backup-"+today()+".json");startActivityForResult(i,44);}catch(Exception e){msg("تعذر فتح حفظ الملف");}}
    protected void onActivityResult(int req,int res,Intent dataIntent){super.onActivityResult(req,res,dataIntent);if(req==44&&res==RESULT_OK&&dataIntent!=null){try(java.io.OutputStream os=getContentResolver().openOutputStream(dataIntent.getData())){os.write(data.toString(2).getBytes("UTF-8"));msg("Sauvegarde exportée");}catch(Exception e){msg("Erreur de sauvegarde");}}}
    void msg(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
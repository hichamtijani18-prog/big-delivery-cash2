package com.bigdelivery.cash;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    final int NAVY=Color.rgb(11,27,54), BLUE=Color.rgb(18,103,241), ORANGE=Color.rgb(255,120,31),
        BG=Color.rgb(243,246,251), INK=Color.rgb(20,35,61), MUTED=Color.rgb(113,128,154),
        GREEN=Color.rgb(19,155,105), RED=Color.rgb(229,72,77), LINE=Color.rgb(231,237,245);
    JSONObject data, current;
    JSONArray couriers, companies, days, receipts, payments;
    LinearLayout root, content, header, nav;
    String page="dashboard";
    SharedPreferences prefs;
    public void onCreate(Bundle b){
        super.onCreate(b);
        try {
            getWindow().setStatusBarColor(NAVY);
            getWindow().setNavigationBarColor(Color.WHITE);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            prefs=getSharedPreferences("bigcash",0);
            load();
            seedCouriers();
            buildShell();
            render();
        } catch (Throwable e) {
            showStartupError(e);
        }
    }

    void showStartupError(Throwable e){
        StringBuilder details = new StringBuilder();
        details.append("BIG Delivery Cash - erreur au démarrage\n\n");
        details.append(e.getClass().getName()).append(": ").append(String.valueOf(e.getMessage())).append("\n\n");
        for (StackTraceElement line : e.getStackTrace()) {
            details.append("at ").append(line.toString()).append("\n");
        }
        ScrollView scroll = new ScrollView(this);
        TextView error = new TextView(this);
        error.setText(details.toString());
        error.setTextSize(14);
        error.setTextColor(Color.BLACK);
        error.setPadding(24, 24, 24, 24);
        error.setTextIsSelectable(true);
        scroll.addView(error);
        setContentView(scroll);
    }
    JSONObject obj(){return new JSONObject();}
    JSONArray arr(){return new JSONArray();}
    void load(){
        try {
            String raw=prefs.getString("state",null);
            if(raw==null){data=obj();couriers=arr();companies=arr();days=arr();current=obj();receipts=arr();payments=arr();current.put("date",today());current.put("receipts",receipts);current.put("payments",payments);current.put("closed",false);data.put("couriers",couriers);data.put("companies",companies);data.put("days",days);data.put("current",current);save();}
            else {data=new JSONObject(raw);couriers=data.getJSONArray("couriers");companies=data.getJSONArray("companies");days=data.getJSONArray("days");current=data.getJSONObject("current");receipts=current.getJSONArray("receipts");payments=current.getJSONArray("payments");}
        }catch(Exception e){data=obj();couriers=arr();companies=arr();days=arr();current=obj();receipts=arr();payments=arr();try{current.put("date",today());current.put("receipts",receipts);current.put("payments",payments);}catch(Exception x){}}
    }
    void save(){try{current.put("receipts",receipts);current.put("payments",payments);data.put("couriers",couriers);data.put("companies",companies);data.put("days",days);data.put("current",current);prefs.edit().putString("state",data.toString()).apply();}catch(Exception e){}}
    void seedCouriers(){
        String[] names={"MOUHAMED ELGA","Youness banassar","Youssef Ait boujmaa","Reda","Jamal ben bihi","Ahmed Baaziz","Ayoub ait lachgu er","SOUFIANE HASSISSOU","Hamza oualla","ABDERRAZAK BENBIHI","Ahmed","Abdelaaziz","MOHAMED NID BOUFKER","Tallal Ikizzi","Ikkizi salah eddine","Youssef ait Aissa","HAMZA ERRAMI"};
        boolean changed=false;
        for(String name:names){boolean exists=false;for(int i=0;i<couriers.length();i++){JSONObject o=couriers.optJSONObject(i);if(o!=null&&name.equalsIgnoreCase(o.optString("name").trim())){exists=true;break;}}if(!exists){JSONObject e=obj();try{e.put("id",UUID.randomUUID().toString());e.put("name",name);couriers.put(e);changed=true;}catch(Exception ignored){}}}
        if(changed)save();
    }
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.FRANCE).format(new Date());}
    String fmt(double n){return NumberFormat.getNumberInstance(Locale.FRANCE).format(n)+" DH";}
    double sum(JSONArray a){double n=0;for(int i=0;i<a.length();i++)n+=a.optJSONObject(i).optDouble("amount",0);return n;}
    double sumFor(JSONArray a,String id){double n=0;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(id.equals(o.optString("entityId")))n+=o.optDouble("amount",0);}return n;}
    double cash(){return sum(receipts);} double paid(){return sum(payments);} double balance(){return cash()-paid();}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    TextView button(String s,int color,int fg,Runnable action){TextView t=text(s,13,fg,true);t.setGravity(Gravity.CENTER);pad(t,12,13,12,13);t.setBackground(bg(color,14));t.setOnClickListener(v->action.run());return t;}
    void buildShell(){
        root=column();root.setBackgroundColor(BG);setContentView(root);
        header=column();header.setBackground(bg(NAVY,0));pad(header,18,17,18,18);
        LinearLayout brand=row();TextView logo=text("B",20,Color.WHITE,true);logo.setGravity(Gravity.CENTER);logo.setBackground(bg(ORANGE,14));brand.addView(logo,lp(44,44));
        LinearLayout brandtxt=column();pad(brandtxt,10,0,0,0);brandtxt.addView(text("BIG DELIVERY",17,Color.WHITE,true));brandtxt.addView(text("CASH MANAGER",10,Color.rgb(185,201,225),true));brand.addView(brandtxt,new LinearLayout.LayoutParams(0,-2,1));
        brand.addView(button("+ Nouveau jour",Color.rgb(233,240,255),BLUE,()->newDayConfirm()));header.addView(brand);TextView date=text(today(),12,Color.rgb(200,215,235),false);pad(date,0,13,0,0);header.addView(date);root.addView(header,lp(-1,-2));
        ScrollView sc=new ScrollView(this);content=column();pad(content,16,14,16,36);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();
        nav.setBackgroundColor(Color.WHITE);
        nav.setPadding(0,0,0,dp(12)); // keep labels clear of Android's gesture bar
        nav.setElevation(dp(8));
        String[][] items={{"⌂","Accueil","dashboard"},{"♙","Livreurs","couriers"},{"▤","Sociétés","companies"},{"◷","Historique","history"},{"⚙","Réglages","settings"}};
        for(String[] it:items){
            final String targetPage=it[2];
            LinearLayout item=column();
            item.setGravity(Gravity.CENTER);
            item.setClickable(true);
            item.setFocusable(true);
            item.setMinimumHeight(dp(64));
            item.setBackgroundResource(android.R.drawable.list_selector_background);
            item.setContentDescription(it[1]);
            item.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            pad(item,2,7,2,5);
            TextView icon=text(it[0],20,MUTED,true);
            icon.setGravity(Gravity.CENTER);
            icon.setClickable(false);
            icon.setFocusable(false);
            TextView label=text(it[1],10,MUTED,true);
            label.setGravity(Gravity.CENTER);
            label.setClickable(false);
            label.setFocusable(false);
            item.addView(icon,lp(-1,25));
            item.addView(label,lp(-1,18));
            item.setOnClickListener(v->{
                page=targetPage;
                render();
            });
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(64),1));
        }
        root.addView(nav,lp(-1,-2));
    }
    void heading(String title,String sub){content.addView(text(title,22,INK,true));TextView s=text(sub,12,MUTED,false);pad(s,0,4,0,13);content.addView(s);}
    LinearLayout card(){LinearLayout c=column();c.setBackground(bg(Color.WHITE,18));pad(c,15,15,15,15);LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(11);content.addView(c,p);return c;}
    void metric(LinearLayout c,String label,double value,int accent,String symbol){LinearLayout r=row();TextView icon=text(symbol,22,accent,true);icon.setGravity(Gravity.CENTER);icon.setBackground(bg(accent==GREEN?0xffe4f8ef:accent==RED?0xfffff0ef:0xfffff0e5,14));r.addView(icon,lp(44,44));LinearLayout box=column();pad(box,12,0,0,0);box.addView(text(label,11,MUTED,true));box.addView(text(fmt(value),22,accent,true));r.addView(box);c.addView(r);}
    void render(){
        content.removeAllViews();
        if(page.equals("dashboard"))dashboard();
        else if(page.equals("couriers"))entities(true);
        else if(page.equals("companies"))entities(false);
        else if(page.equals("history"))history();
        else settings();
        String[] pages={"dashboard","couriers","companies","history","settings"};
        for(int i=0;i<nav.getChildCount();i++){
            LinearLayout item=(LinearLayout)nav.getChildAt(i);
            TextView icon=(TextView)item.getChildAt(0),label=(TextView)item.getChildAt(1);
            boolean selected=page.equals(pages[i]);
            icon.setTextColor(selected?BLUE:MUTED);
            label.setTextColor(selected?BLUE:MUTED);
            item.setSelected(selected);
            item.setContentDescription(label.getText().toString()+(selected?", page active":""));
        }
    }
    void dashboard(){
        heading("Vue d’ensemble","Suivi du cash — journée en cours");
        LinearLayout c=card();metric(c,"TOTAL CASH REÇU",cash(),GREEN,"↓");
        c=card();metric(c,"TOTAL PAYÉ AUX SOCIÉTÉS",paid(),RED,"↗");
        c=card();metric(c,"RESTE EN CAISSE",balance(),ORANGE,"▣");
        LinearLayout r=row();TextView a=button("+ Cash reçu",BLUE,Color.WHITE,()->transaction(true,null));TextView b=button("+ Paiement",ORANGE,Color.WHITE,()->transaction(false,null));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);p.rightMargin=dp(7);r.addView(a,p);r.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));LinearLayout.LayoutParams rp=lp(-1,-2);rp.bottomMargin=dp(13);content.addView(r,rp);
        c=card();c.addView(text("Dernières opérations",15,INK,true));JSONArray tx=allTx(current);if(tx.length()==0)c.addView(empty("Aucune opération pour le moment."));else for(int i=Math.max(0,tx.length()-5);i<tx.length();i++){JSONObject o=tx.optJSONObject(i);addTxRow(c,o);}
    }
    TextView empty(String s){TextView t=text(s,13,MUTED,false);t.setGravity(Gravity.CENTER);pad(t,5,20,5,20);return t;}
    JSONArray allTx(JSONObject day){JSONArray out=arr();JSONArray a=day.optJSONArray("receipts"),b=day.optJSONArray("payments");if(a!=null)for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);try{o.put("type","receipt");out.put(o);}catch(Exception e){}}if(b!=null)for(int i=0;i<b.length();i++){JSONObject o=b.optJSONObject(i);try{o.put("type","payment");out.put(o);}catch(Exception e){}}return out;}
    void addTxRow(LinearLayout c,JSONObject o){
        LinearLayout item=column();
        LinearLayout r=row();
        TextView n=text(o.optString("name"),13,INK,true);
        r.addView(n,new LinearLayout.LayoutParams(0,-2,1));
        boolean rec=o.optString("type").equals("receipt");
        r.addView(text((rec?"+ ":"− ")+fmt(o.optDouble("amount")),13,rec?GREEN:RED,true));
        pad(r,0,12,0,6);
        r.setClickable(true);r.setFocusable(true);r.setBackgroundResource(android.R.drawable.list_selector_background);
        r.setOnClickListener(v->manageTransaction(current,o));
        item.addView(r);
        String noteValue=o.optString("note","").trim();
        if(!noteValue.isEmpty()){
            TextView noteView=text(noteValue,12,MUTED,false);
            noteView.setGravity(Gravity.CENTER);
            noteView.setBackground(bg(0xfff2f6fc,10));
            pad(noteView,10,8,10,8);
            LinearLayout.LayoutParams noteParams=lp(-1,-2);
            noteParams.setMargins(dp(12),dp(2),dp(12),dp(8));
            item.addView(noteView,noteParams);
        }
        TextView hint=text("✎ Modifier / Supprimer",10,BLUE,true);
        pad(hint,0,0,0,8);
        hint.setOnClickListener(v->manageTransaction(current,o));
        item.addView(hint);
        View line=new View(this);line.setBackgroundColor(LINE);item.addView(line,lp(-1,1));
        c.addView(item);
    }
    JSONArray list(boolean courier){return courier?couriers:companies;}
    void entities(boolean courier){
        heading(courier?"Livreurs":"Sociétés",courier?(""+couriers.length()+" livreur(s) · Choisissez un livreur et saisissez le total remis."):"Consultez les paiements effectués aux sociétés.");
        if(courier){
            content.addView(button("+ Ajouter un livreur",BLUE,Color.WHITE,()->addName(true)));
            LinearLayout.LayoutParams bulkP=lp(-1,44);bulkP.topMargin=dp(7);
            content.addView(button("+ Ajouter plusieurs livreurs",0xfffff0e5,ORANGE,()->addManyCouriers()),bulkP);
        } else content.addView(button("+ Ajouter une société",BLUE,Color.WHITE,()->addName(false)));
        content.addView(new View(this),lp(1,10));
        JSONArray arr=list(courier);
        if(arr.length()==0){LinearLayout emptyCard=card();emptyCard.addView(empty(courier?"Aucun livreur. Ajoutez un nom pour commencer.":"Aucune société. Ajoutez un nom pour commencer."));return;}
        for(int i=0;i<arr.length();i++){
            JSONObject e=arr.optJSONObject(i);if(e==null)continue;
            final int index=i;String id=e.optString("id"),name=e.optString("name");
            LinearLayout c=card();c.addView(text(name,15,INK,true));
            c.addView(text((courier?"Total reçu aujourd’hui : ":"Payé aujourd’hui : ")+fmt(sumFor(courier?receipts:payments,id)),12,courier?GREEN:RED,false));
            TextView b=button(courier?"+ Montant reçu":"+ Paiement",courier?0xffeaf1ff:0xfffff0e5,courier?BLUE:ORANGE,()->transaction(courier,id));
            LinearLayout.LayoutParams p=lp(-1,46);p.topMargin=dp(10);c.addView(b,p);
            LinearLayout actions=row();
            TextView edit=button("✎ Modifier",0xffeef4ff,BLUE,()->editEntity(courier,id));
            TextView del=button("Supprimer",0xffffeeee,RED,()->deleteEntity(courier,id));
            LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(46),1);ap.topMargin=dp(8);ap.rightMargin=dp(5);actions.addView(edit,ap);
            LinearLayout.LayoutParams dp2=new LinearLayout.LayoutParams(0,dp(46),1);dp2.topMargin=dp(8);dp2.leftMargin=dp(5);actions.addView(del,dp2);c.addView(actions);
            if(courier){
                LinearLayout order=row();
                TextView up=button("↑ Monter",0xfff1f5fb,INK,()->moveCourier(id,-1));
                TextView down=button("↓ Descendre",0xfff1f5fb,INK,()->moveCourier(id,1));
                LinearLayout.LayoutParams op1=new LinearLayout.LayoutParams(0,dp(42),1);op1.topMargin=dp(7);op1.rightMargin=dp(5);order.addView(up,op1);
                LinearLayout.LayoutParams op2=new LinearLayout.LayoutParams(0,dp(42),1);op2.topMargin=dp(7);op2.leftMargin=dp(5);order.addView(down,op2);c.addView(order);
                up.setEnabled(index>0);up.setAlpha(index>0?1f:0.45f);down.setEnabled(index<arr.length()-1);down.setAlpha(index<arr.length()-1?1f:0.45f);
            }
        }
    }
    void moveCourier(String id,int delta){
        int from=-1;for(int i=0;i<couriers.length();i++){JSONObject o=couriers.optJSONObject(i);if(o!=null&&o.optString("id").equals(id)){from=i;break;}}
        int to=from+delta;if(from<0||to<0||to>=couriers.length())return;
        try{JSONObject a=couriers.getJSONObject(from),b=couriers.getJSONObject(to);JSONArray reordered=arr();for(int i=0;i<couriers.length();i++){if(i==from)reordered.put(b);else if(i==to)reordered.put(a);else reordered.put(couriers.get(i));}couriers=reordered;data.put("couriers",couriers);save();render();}catch(Exception ignored){}
    }
    void editEntity(boolean courier,String id){JSONArray a=list(courier);JSONObject target=null;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optString("id").equals(id)){target=o;break;}}if(target==null)return;final JSONObject selectedEntity=target;EditText input=new EditText(this);input.setSingleLine(true);input.setText(selectedEntity.optString("name"));LinearLayout box=column();pad(box,20,8,20,8);box.addView(input);new AlertDialog.Builder(this).setTitle(courier?"Modifier le livreur":"Modifier la société").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty()){msg("Le nom est obligatoire");return;}for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&!o.optString("id").equals(id)&&name.equalsIgnoreCase(o.optString("name"))){msg("Ce nom existe déjà");return;}}try{selectedEntity.put("name",name);renameTransactions(id,name);}catch(Exception ignored){}save();render();msg("Nom modifié");}).show();}
    void renameTransactions(String id,String name){JSONArray all=arr();all.put(current);for(int i=0;i<days.length();i++)all.put(days.optJSONObject(i));for(int i=0;i<all.length();i++){JSONObject day=all.optJSONObject(i);if(day==null)continue;for(String key:new String[]{"receipts","payments"}){JSONArray tx=day.optJSONArray(key);if(tx==null)continue;for(int j=0;j<tx.length();j++){JSONObject t=tx.optJSONObject(j);if(t!=null&&t.optString("entityId").equals(id))try{t.put("name",name);}catch(Exception ignored){}}}}}
    void deleteEntity(boolean courier,String id){JSONArray a=list(courier);JSONObject target=null;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optString("id").equals(id)){target=o;break;}}if(target==null)return;String name=target.optString("name");new AlertDialog.Builder(this).setTitle("Supprimer « "+name+" » ?").setMessage("Le nom sera retiré de la liste. Les anciennes opérations resteront dans l’historique.").setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{JSONArray updated=arr();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null||!o.optString("id").equals(id))updated.put(o);}try{data.put(courier?"couriers":"companies",updated);if(courier)couriers=updated;else companies=updated;}catch(Exception ignored){}save();render();msg("Élément supprimé de la liste");}).show();}
    void addName(boolean courier){EditText input=new EditText(this);input.setSingleLine(true);input.setHint(courier?"Nom du livreur":"Nom de la société");LinearLayout box=column();pad(box,20,8,20,8);box.addView(input);new AlertDialog.Builder(this).setTitle(courier?"Ajouter un livreur":"Ajouter une société").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty())return;JSONArray a=list(courier);for(int i=0;i<a.length();i++)if(a.optJSONObject(i).optString("name").equalsIgnoreCase(name)){msg("Ce nom existe déjà");return;}JSONObject e=obj();try{e.put("id",UUID.randomUUID().toString());e.put("name",name);a.put(e);}catch(Exception ex){}save();render();}).show();}
    void addManyCouriers(){
        EditText input=new EditText(this);input.setHint("Un nom par ligne\nEx.\nReda\nYouness\nHamza");input.setMinLines(5);input.setGravity(android.view.Gravity.TOP|android.view.Gravity.START);input.setPadding(dp(14),dp(12),dp(14),dp(12));input.setBackground(bg(0xffe8f1ff,18));
        LinearLayout box=column();pad(box,18,8,18,8);box.addView(text("Écrivez un nom par ligne. Les doublons seront ignorés.",12,MUTED,false));box.addView(new View(this),lp(1,8));box.addView(input);
        new AlertDialog.Builder(this).setTitle("Ajouter plusieurs livreurs").setView(box).setNegativeButton("Annuler",null).setPositiveButton("Ajouter",(d,w)->{
            String[] lines=input.getText().toString().split("[\\r\\n,;]+");int added=0,skipped=0;
            for(String raw:lines){String name=raw.trim();if(name.isEmpty())continue;boolean exists=false;for(int i=0;i<couriers.length();i++){JSONObject o=couriers.optJSONObject(i);if(o!=null&&name.equalsIgnoreCase(o.optString("name").trim())){exists=true;break;}}if(exists){skipped++;continue;}JSONObject e=obj();try{e.put("id",UUID.randomUUID().toString());e.put("name",name);couriers.put(e);added++;}catch(Exception ignored){}}
            save();render();msg(added+" livreur(s) ajouté(s) · "+skipped+" doublon(s) ignoré(s)");
        }).show();
    }
    void transaction(boolean receipt,String selected){
        JSONArray arr=list(receipt);
        if(arr.length()==0){msg(receipt?"Ajoutez d’abord un livreur":"Ajoutez d’abord une société");page=receipt?"couriers":"companies";render();return;}

        LinearLayout form=column();
        pad(form,20,8,20,8);
        form.setBackground(bg(0xfffff0e5,22));

        TextView chooseLabel=text(receipt?"Livreur":"Société",12,MUTED,true);
        form.addView(chooseLabel);
        Spinner spinner=new Spinner(this);
        spinner.setPadding(dp(10),dp(8),dp(10),dp(8));
        spinner.setBackground(bg(0xffe8f1ff,20));
        ArrayList<String> names=new ArrayList<>();
        names.add(receipt?"— Choisir un livreur —":"— Choisir une société —");
        int idx=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null)continue;
            names.add(o.optString("name"));
            if(selected!=null && o.optString("id").equals(selected))idx=names.size()-1;
        }
        ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,names);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(ad);
        spinner.setSelection(idx);
        LinearLayout.LayoutParams sp=lp(-1,-2);sp.topMargin=dp(6);sp.bottomMargin=dp(16);form.addView(spinner,sp);

        TextView amountLabel=text("Montant (DH)",12,MUTED,true);form.addView(amountLabel);
        EditText amount=new EditText(this);amount.setSingleLine(true);amount.setHint("Ex. 500");amount.setInputType(receipt?12290:8194);amount.setPadding(dp(12),dp(10),dp(12),dp(10));amount.setBackground(bg(0xffe8f1ff,20));
        LinearLayout.LayoutParams ap=lp(-1,-2);ap.topMargin=dp(6);ap.bottomMargin=dp(14);form.addView(amount,ap);

        TextView noteLabel=text("Note (facultative)",12,MUTED,true);form.addView(noteLabel);
        EditText note=new EditText(this);note.setSingleLine(true);note.setHint("Ajouter une note");note.setPadding(dp(12),dp(10),dp(12),dp(10));note.setBackground(bg(0xffe8f1ff,20));form.addView(note);

        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle(receipt?"Cash reçu":"Paiement société")
            .setView(form)
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Confirmer",null).create();
        dialog.setOnShowListener(v->{if(dialog.getWindow()!=null)dialog.getWindow().setBackgroundDrawable(bg(0xfffff0e5,24));dialog.getButton(-1).setTextColor(BLUE);dialog.getButton(-2).setTextColor(MUTED);dialog.getButton(-1).setOnClickListener(view->{
            if(spinner.getSelectedItemPosition()<=0){msg(receipt?"Choisissez un livreur":"Choisissez une société");return;}
            try{
                double n=Double.parseDouble(amount.getText().toString().trim().replace(',','.'));
                if(receipt ? n==0 : n<=0)throw new Exception();
                JSONObject ent=arr.optJSONObject(spinner.getSelectedItemPosition()-1);
                if(ent==null)throw new Exception();
                JSONObject t=obj();t.put("id",UUID.randomUUID().toString());t.put("entityId",ent.optString("id"));t.put("name",ent.optString("name"));t.put("amount",n);t.put("note",note.getText().toString().trim());t.put("date",System.currentTimeMillis());
                (receipt?receipts:payments).put(t);save();dialog.dismiss();render();msg("Opération enregistrée");
            }catch(Exception ex){msg("Vérifiez le montant saisi");}
        });});
        dialog.show();
    }
    void newDayConfirm(){new AlertDialog.Builder(this).setTitle("Commencer un nouveau jour ?").setMessage("La journée du "+current.optString("date")+" sera archivée. Le nouveau solde commencera à 0 DH. Les noms et l’historique seront conservés.\\n\\nCash reçu : "+fmt(cash())+"\\nPayé : "+fmt(paid())+"\\nReste : "+fmt(balance())).setNegativeButton("Annuler",null).setPositiveButton("Archiver & continuer",(d,w)->{try{current.put("closed",true);days.put(current);current=obj();receipts=arr();payments=arr();current.put("date",today());current.put("receipts",receipts);current.put("payments",payments);current.put("closed",false);save();page="dashboard";render();msg("Nouvelle journée : solde à 0 DH");}catch(Exception e){}}).show();}
    void history(){heading("Historique","Les journées clôturées restent consultables.");for(int i=-1;i<days.length();i++){JSONObject d=i<0?current:days.optJSONObject(days.length()-1-i);JSONArray r=d.optJSONArray("receipts"),p=d.optJSONArray("payments");double c=sum(r==null?arr():r),v=sum(p==null?arr():p);LinearLayout card=card();card.addView(text((d.optBoolean("closed")?"Journée du ":"Journée en cours · ")+d.optString("date"),15,INK,true));card.addView(text("Total cash : "+fmt(c),13,GREEN,true));card.addView(text("Total payé : "+fmt(v),13,RED,true));card.addView(text("Reste : "+fmt(c-v),13,ORANGE,true));TextView view=button("▣  Ouvrir cette journée · Voir les opérations",0xffeaf1ff,BLUE,()->viewDay(d));LinearLayout.LayoutParams lp=lp(-1,42);lp.topMargin=dp(9);card.addView(view,lp);}}
    void viewDay(JSONObject d){
        JSONArray tx=allTx(d);
        if(tx.length()==0){new AlertDialog.Builder(this).setTitle("Journée du "+d.optString("date")).setMessage("Aucune opération").setPositiveButton("Fermer",null).show();return;}
        String[] labels=new String[tx.length()];
        for(int i=0;i<tx.length();i++){JSONObject o=tx.optJSONObject(i);labels[i]=o.optString("name")+" — "+fmt(o.optDouble("amount"))+(o.optString("type").equals("receipt")?" (Cash reçu)":" (Paiement)")+"\nAppuyez pour modifier ou supprimer";}
        new AlertDialog.Builder(this).setTitle("Opérations · "+d.optString("date")).setItems(labels,(dialog,which)->manageTransaction(d,tx.optJSONObject(which))).setNegativeButton("Fermer",null).show();
    }
    void manageTransaction(JSONObject day,JSONObject tx){
        if(tx==null)return;
        boolean receipt=tx.optString("type").equals("receipt");
        String[] actions={"Modifier le montant / la note","Supprimer cette opération","Annuler"};
        new AlertDialog.Builder(this).setTitle(tx.optString("name")+" · "+fmt(tx.optDouble("amount"))).setItems(actions,(dialog,which)->{
            if(which==0)editTransaction(day,tx,receipt);
            else if(which==1)new AlertDialog.Builder(this).setTitle("Supprimer l’opération ?").setMessage("Cette action recalculera automatiquement les totaux.").setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{removeTransaction(day,tx,receipt);save();render();msg("Opération supprimée");}).show();
        }).show();
    }
    void editTransaction(JSONObject day,JSONObject tx,boolean receipt){
        LinearLayout form=column();pad(form,20,8,20,8);
        EditText amount=new EditText(this);amount.setHint("Montant en DH");amount.setInputType(receipt?12290:8194);amount.setText(String.valueOf(tx.optDouble("amount")));
        EditText note=new EditText(this);note.setHint("Note (facultative)");note.setText(tx.optString("note"));
        form.addView(text("Montant (DH)",12,MUTED,true));form.addView(amount);form.addView(text("Note",12,MUTED,true));form.addView(note);
        new AlertDialog.Builder(this).setTitle("Modifier l’opération").setView(form).setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(dialog,which)->{
            try{double value=Double.parseDouble(amount.getText().toString().trim().replace(',','.'));if(value<=0)throw new Exception();tx.put("amount",value);tx.put("note",note.getText().toString().trim());replaceTransaction(day,tx,receipt);save();render();msg("Opération modifiée");}
            catch(Exception e){msg("Montant invalide");}
        }).show();
    }
    void replaceTransaction(JSONObject day,JSONObject tx,boolean receipt){
        JSONArray a=day.optJSONArray(receipt?"receipts":"payments");if(a==null)return;
        for(int i=0;i<a.length();i++){JSONObject item=a.optJSONObject(i);if(item!=null&&item.optString("id").equals(tx.optString("id"))){try{a.put(i,tx);}catch(Exception ignored){}break;}}
        if(day==current){receipts=current.optJSONArray("receipts");payments=current.optJSONArray("payments");}
    }
    void removeTransaction(JSONObject day,JSONObject tx,boolean receipt){
        JSONArray a=day.optJSONArray(receipt?"receipts":"payments");if(a==null)return;
        for(int i=0;i<a.length();i++){JSONObject item=a.optJSONObject(i);if(item!=null&&item.optString("id").equals(tx.optString("id"))){JSONArray updated=arr();for(int j=0;j<a.length();j++)if(j!=i)updated.put(a.opt(j));try{day.put(receipt?"receipts":"payments",updated);}catch(Exception ignored){}break;}}
        if(day==current){receipts=current.optJSONArray("receipts");payments=current.optJSONArray("payments");}
    }
    void settings(){heading("Réglages","Sauvegarde locale des données.");LinearLayout c=card();c.addView(text("Les données sont enregistrées sur ce téléphone. Elles ne sont pas synchronisées avec d’autres appareils.",13,MUTED,false));c.addView(button("Exporter une sauvegarde",BLUE,Color.WHITE,()->exportBackup()));c.addView(text("Pour éviter de perdre vos données, exportez régulièrement une sauvegarde.",12,MUTED,false));}
    void exportBackup(){try{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"big-delivery-backup-"+today()+".json");startActivityForResult(i,44);}catch(Exception e){msg("تعذر فتح حفظ الملف");}}
    protected void onActivityResult(int req,int res,Intent dataIntent){super.onActivityResult(req,res,dataIntent);if(req==44&&res==RESULT_OK&&dataIntent!=null){try(java.io.OutputStream os=getContentResolver().openOutputStream(dataIntent.getData())){os.write(data.toString(2).getBytes("UTF-8"));msg("Sauvegarde exportée");}catch(Exception e){msg("Erreur de sauvegarde");}}}
    void msg(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}